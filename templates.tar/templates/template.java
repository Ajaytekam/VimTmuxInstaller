import java.util.*;

class MyClass {
	public static void main(String args[]) {

	}
}
